//Classes are the core of object oriented programming (OOP). 
//They make your code more secure and encapsulated. 
//Using classes gives your code a nice structure and keeps it oriented.


class MyClass {
    constructor(name, age){
        this.name = name;
        this.age = age;
    }
}
const home = new MyClass('Virat', 30);
console.log(home);
console.log(home.name);


//We can create class in ES6 using “class” keyword. 
//Class syntax has two components: class expressions and class declarations.
//To declare a class, you use the class keyword with the name of the class ("Profile" here).

class Profile {
    constructor(firstName, lastName = ''){
        this.firstName = firstName;
        this.lastName = lastName;
    }
    getName(){  //class method
        console.log(`Name: ${this.firstName} ${this.lastName}`);
    }
}
let profilObj = new Profile('John', 'Doe');
profilObj.getName();


//An important difference between function declarations and class declarations is 
//that function declarations are hoisted and 
//class declarations are not.
//You first need to declare your class and then access it, 
//otherwise code like the following will throw a ReferenceError:


/* -----------------------------------Class Expression---------------------------------------*/
/*-------un Named ----*/
let rectangle = class {
    constructor(height, width){
        this.height = height;
        this.width = width;
    }
};
console.log(rectangle.name);

/*-------Named ----*/
let rectangle2 = class Circle {
    constructor(height, width) {
        this.height = height;
        this.width = width;
    }
};
console.log(rectangle2.name);

/** Constructor */

/**The constructor method is a special method for creating and initializing an object created with a class.
 *  There can only be one special method with the name "constructor" in a class. 
 * A SyntaxError will be thrown if the class contains more than one occurrence of a constructor method.
A constructor can use the super keyword to call the constructor of the super class. */