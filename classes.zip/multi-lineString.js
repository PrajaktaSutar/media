//backtick character

let poemData = `Johny Johny Yes Papa,
                Eating sugar?  No, papa!
                Telling lies? No, papa!
                Open your mouth Ah, ah, ah!`

console.log(poemData);


// var poemData = 'Johny Johny Yes Papa,\n'
//     + 'Eating sugar?  No, papa!\n'
//     + 'Telling lies? No, papa!\n'
//     + 'Open your mouth Ah, ah, ah!'
