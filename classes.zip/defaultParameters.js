// function(param1 = value1, param2 = value2)

let calculateArea = function(height = 15, width = 10)  {
    this.height = height;
    this.width = width;
    return height * width;
}

calculateArea();
// console.log(calculateArea());
// console.log(calculateArea(5,2));


//example 2
function getUser(name, year = 2019) {
    this.name = name;
    this.year = year;
    return name + ' ' + year;
}

// getUser(Virat);
console.log(getUser('virat'));
