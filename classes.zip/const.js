const x = 1;
x = 5;  //can't able to reassign the value using const keyword
console.log(x);