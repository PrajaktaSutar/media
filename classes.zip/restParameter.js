function numeric(x, ...z ){
    console.log(x, z);
}
numeric(1,2,3,4,5,6,7);

