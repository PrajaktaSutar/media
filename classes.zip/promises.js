/**
 * Promises are a new feature of ES6. 
 * It’s a method to write asynchronous code. 
 * It can be used when, we want to fetch data from an API, 
 * or when we have a function that takes time to be executed. 
 * Promises make it easier to solve the problem, so let’s create our first Promise!
 */


/**
* Imagine that you’re a top singer, and fans ask day and night for your upcoming single.
To get some relief, you promise to send it to them when it’s published.
You give your fans a list to which they can subscribe for updates.
They can fill in their email addresses, so that when the song becomes available, 
all subscribed parties instantly receive it.
And even if something goes very wrong, say, if plans to publish the song are cancelled, 
they will still be notified. Everyone is happy, because the people don’t crowd you any more, and fans, 
because they won’t miss the single.* 
*/

//  let promises = new Promises(function (resolve, reject) {
//      // executor (the producing code, "singer")
//      if (condition) {
         
//      }
//  })


let promise = new Promise(function (resolve, reject) {
    // the function is executed automatically when the promise is constructed

    // after 1 second signal that the job is done with the result "done"
    setTimeout(() => resolve("done"), 100);
});

console.log(promise);


// let p1 = new Promise((resolve, reject) => {
//     setTimeout(() => resolve("1"), 101)
// })
// let p2 = new Promise((resolve, reject) => {
//     setTimeout(() => resolve("2"), 100)
// })

// Promise.race([p1, p2]).then((res) => {
//     console.log(res)
// })

// Promise.all([p1, p2]).then((res) => {
//     console.log(res)
// })
