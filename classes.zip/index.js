// function showValues(params) {
//     let i = 2;
//     if ((i % 3 == 0) && (i % 15 == 0)) {
//         console.log('Mohammed Imran');
//     }
//     else if (i % 3 == 0) {
//         console.log('Mohammed');
//     }
//     else if (i % 15 == 0) {
//         console.log('Imran');
//     }
//     else {
//         console.log('I am Not a Mohammed Imran');
//     }
// }
// showValues();

let royalChallengers = ['Dhawan', 'KL Rahul', 'Bairstow', 'Virat', 'Pant', 'Hardik', 'Russ', 'Tahir', 'Gopal', 'Bumra', 'Rabada'];

let rcbPlayers = (avg) => {
    this.avg = avg;
}

