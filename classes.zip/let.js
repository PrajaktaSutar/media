//ES5
/*function helloworld() {
    for (var x = 0; x < 2; x++) {
        // x should only be scoped to this block because this is where we havedefined x. 
   }
    // But it turns out that x is available here as well! 
    console.log(x); // 2
}
*/

//ES6
function helloWorld() {
    for (let i = 0; i < 5; i++) {
        console.log(i); // i accessible in this block
    }
    // console.log(i);     // i is not defined
}
helloWorld();



let x = 15;
x = 25; //We can reassign the value by using let keyword
console.log(`My x value is ${x}`);
