// $ {PARAMETER}
//backtick character

const fullName = 'Mohammed Imran';
const myPinCode = 400088;

const myDetail = `I am ${fullName} and my area code is ${myPinCode}`;
console.log(myDetail);
