let sumArray = [10, 20, 30];

function getSum(x, y, z) {
    // console.log(x + y + z);
}
getSum(...sumArray);


//example 2
let firstValue = [10, 20];
let secValue = [30, 40];

const result = [...firstValue, ...secValue];
console.log(result);
