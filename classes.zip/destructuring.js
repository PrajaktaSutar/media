let data = {
    p: 42,
    q: true
};

let {p, q} = data;

// console.log(p);
// console.log(q);

//unpack the values from arrays, or properties from objects into distinct values

let bioData = {
    name: 'Imran',
    designation: 'SA',
    branch: 'Mumbai',
}
let { name, branch, designation } = bioData;
// console.log(designation);
// console.log(name);
// console.log(branch);


let fruits = ['apple', 'orange', 'grapes'];
let [ kashmir, kerala, TN ] = fruits;

// console.log(fruits);
// console.log(kashmir);
// console.log(kerala);
// console.log(TN);

//example 3
const address = {
    street: 'main Rd',
    city: 'Chennai',
    state: 'TN'
}
// console.log(address);

//unpack the properties from object
const { street, city, state } = address;
// console.log(street);
// console.log(city);
// console.log(state);


//example 4 - arrays

const values = [ 'Hello', 'Falah' ];
const [Greeting, greetingMsg] = values;
console.log(Greeting);
console.log(greetingMsg);







